sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (Controller, MessageBox) {

    return Controller.extend("logaligroup.Employees.controller.App", {

        onInit: function () {

        }
    });
});